package com.dhruvi.createit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.CheckBox;
import java.util.HashMap;

public class shop_now extends AppCompatActivity {

    HashMap<String,Double> selection = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_now);

    }


    public void selectItem(View view) {
        boolean checked= ((CheckBox)view).isChecked();
        switch(view.getId()){
            case R.id.cb_h1:

                if(checked)
                    selection.put("Room Decor",450.0);
                else
                    selection.remove("Room Decor");
                break;

            case R.id.cb_h2:

                if(checked)
                    selection.put("Farmhouse Style Decor",560.0);
                else
                    selection.remove("Farmhouse Style Decor");
                break;

            case R.id.cb_h3:

                if(checked)
                    selection.put("Wall Hanging",350.0);
                else
                    selection.remove("Wall Hanging");
                break;

            case R.id.cb_b1:

                if(checked)
                    selection.put("Newspaper Cycle",850.0);
                else
                    selection.remove("Newspaper Cycle");
                break;

            case R.id.cb_b2:

                if(checked)
                    selection.put("Newspaper Flower Vase",420.0);
                else
                    selection.remove("Newspaper Flower Vase");
                break;

            case R.id.cb_b3:

                if(checked)
                    selection.put("Candle Holder",700.0);
                else
                    selection.remove("Canedle Holder");
                break;

            case R.id.cb_g1:

                if(checked)
                    selection.put("Birthday Card",150.0);
                else
                    selection.remove("Newspaper Cycle");
                break;

            case R.id.cb_g2:

                if(checked)
                    selection.put("Flower Pop-up Card",300.0);
                else
                    selection.remove("Flower Pop-up Card");
                break;

            case R.id.cb_g3:

                if(checked)
                    selection.put("Teacher's Day Card",240.0);
                else
                    selection.remove("Teacher's Day Card");
                break;

            case R.id.cb_ac1:

                if(checked)
                    selection.put("Matchstick Craft",250.0);
                else
                    selection.remove("Matchstick Craft");
                break;

            case R.id.cb_ac2:

                if(checked)
                    selection.put("Light Bulb Craft",630.0);
                else
                    selection.remove("Light Bulb Craft");
                break;

            case R.id.cb_ac3:

                if(checked)
                    selection.put("Paper Stick Flowers",210.0);
                else
                    selection.remove("Paper Stick Flowers");
                break;
        }
    }

    public void finalSelection(View view) {

        Intent i=new Intent(shop_now.this,buy_now.class);
        i.putExtra("Products",selection);
        startActivity(i);
    }

}
