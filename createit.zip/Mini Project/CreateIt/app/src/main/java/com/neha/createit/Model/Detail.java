package com.dhruvi.createit.Model;

import java.util.HashMap;

public class Detail {

    private String username;
    private String email;
    private String password;
    private HashMap<String,Double> products;
    private String address;

    public Detail()
    {

    }

    public Detail(String username,String email,String password,HashMap<String,Double> products,String address)
    {
        this.username=username;
        this.email=email;
        this.password=password;
        this.products=products;
        this.address=address;
    }

    public String getUsername(){return username;}
    public void setUsername(String username){this.username=username;}

    public String getEmail(){return email;}
    public void setEmail(String email){this.email=email;}

    public String getPassword(){return password;}
    public void setPassword(String password){this.password=password;}

    public HashMap<String, Double> getProducts() {
        return products;
    }

    public void setProducts(HashMap<String, Double> products) {
        this.products = products;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
