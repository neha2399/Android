package com.dhruvi.createit;

public class YouTubeVideos
{
    String videoUrl;
    public YouTubeVideos() {
    }
    public YouTubeVideos(String videoUrl) {
        this.videoUrl = videoUrl;
    }
    public String getVideoUrl() {
        return videoUrl;
    }
    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
