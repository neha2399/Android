package com.dhruvi.createit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.function.DoubleToLongFunction;

public class buy_now extends AppCompatActivity implements View.OnClickListener {

    HashMap<String,Double> pro;
    TextView tn,tp;
    CardView cv;
    CardView ch;
    String purchase="";
    double total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_now);

        tn=findViewById(R.id.prod_name);
        tp=findViewById(R.id.prod_price);

        cv=findViewById(R.id.cont2);
        ch=findViewById(R.id.home);

        cv.setOnClickListener(this);
        ch.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();
        pro = (HashMap<String, Double>) bundle.getSerializable("Products");

        String cost="";
        total=0;

        for (HashMap.Entry<String,Double> entry : pro.entrySet()) {
            purchase=purchase+entry.getKey() + "\n";
            total=total+entry.getValue();
            cost=cost+Double.toString(entry.getValue())+"\n";
        }

        purchase=purchase+"\n"+"Total"+"\n";
        cost=cost+"\n"+Double.toString(total)+"\n";

        tn.setText(purchase);
        tp.setText(cost);
    }

    @Override
    public void onClick(View v) {

        if(v==cv) {

            Intent i = new Intent(buy_now.this, final_bill.class);
            i.putExtra("Total", total);
            i.putExtra("Products", pro);
            startActivity(i);
        }
        else if(v==ch)
        {
            finish();
            startActivity(new Intent(buy_now.this, home_page.class));

        }

    }

}