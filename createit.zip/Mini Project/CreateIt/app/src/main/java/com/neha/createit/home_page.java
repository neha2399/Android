/*package com.dhruvi.createit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

public class home_page extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth firebaseAuth;

    private TextView t;
    private Button b;
    private String uid;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        firebaseAuth= FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser()==null){
            finish();
            startActivity(new Intent(home_page.this, MainActivity.class));
        }

        FirebaseUser user=firebaseAuth.getCurrentUser();

        uid=user.getUid();

        t=(TextView) findViewById(R.id.textUserEmail);

        t.setText("Welcome "+user.getEmail());
        b=(Button) findViewById(R.id.logout);

        b.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent(home_page.this, MainActivity.class));
    }
}*/
package com.dhruvi.createit;

import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.dhruvi.createit.Model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class home_page extends AppCompatActivity implements View.OnClickListener{

    private FirebaseAuth firebaseAuth;

    private TextView t;
    private CardView b;
    private ImageView i1;
    private ImageView i2;
    private ImageView i3;
    private ImageView i4;

    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        firebaseAuth= FirebaseAuth.getInstance();

        t=(TextView) findViewById(R.id.textUserEmail);

        if(firebaseAuth.getCurrentUser()==null){
            finish();
            startActivity(new Intent(home_page.this, MainActivity.class));
        }


        FirebaseUser user=firebaseAuth.getCurrentUser();

        reference = FirebaseDatabase.getInstance().getReference("Users");

        b=(CardView) findViewById(R.id.logout);
        i1= (ImageView) findViewById(R.id.hd_id);
        i2= (ImageView) findViewById(R.id.bw_id);
        i3= (ImageView) findViewById(R.id.art_id);
        i4= (ImageView) findViewById(R.id.card_id);

        b.setOnClickListener(this);
        i1.setOnClickListener(this);
        i2.setOnClickListener(this);
        i3.setOnClickListener(this);
        i4.setOnClickListener(this);

        reference.child(firebaseAuth.getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        User user1 = dataSnapshot.getValue(User.class);


                        if (user1 != null) {
                            t.setText(user1.getUsername());
                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });



    }

    @Override
    public void onClick(View v)
    {
        if(v==b) {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(home_page.this, MainActivity.class));
        }
        else if(v==i1)
        {
            startActivity(new Intent(home_page.this, home_decor.class));
        }
        else if(v==i3)
        {
            startActivity(new Intent(home_page.this, art_and_craft.class));
        }
        else if(v==i2)
        {
            startActivity(new Intent(home_page.this, best_from_waste.class));
        }
        else if(v==i4)
        {
            startActivity(new Intent(home_page.this, greeting_cards.class));
        }

    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }


}

