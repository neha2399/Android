package com.dhruvi.createit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.dhruvi.createit.Model.Detail;
import com.dhruvi.createit.Model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class final_bill extends AppCompatActivity implements View.OnClickListener
{

    TextView t_amt;
    EditText address;
    HashMap<String,Double> pro;
    double total;
    CardView cv;
    CardView ch,cb;

    private FirebaseAuth firebaseAuth;
    FirebaseDatabase database;
    DatabaseReference users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_bill);

        firebaseAuth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        users=database.getReference("Users");

        t_amt=findViewById(R.id.pay_amt);
        address=findViewById(R.id.address);
        cv=findViewById(R.id.buy);
        ch=findViewById(R.id.home);

        Bundle bundle=getIntent().getExtras();
        pro=(HashMap<String, Double>) bundle.getSerializable("Products");
        total=(Double) bundle.getSerializable("Total");
        t_amt.setText("Payment Amount : "+Double.toString(total));

        cv.setOnClickListener(this);
        ch.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void add_data()
    {

        users.child(firebaseAuth.getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        User user1 = dataSnapshot.getValue(User.class);
                        final Detail detail=new Detail(user1.getUsername(),user1.getEmail(),user1.getPassword(),pro,address.getText().toString());

                        String add=address.getText().toString().trim();

                        if (TextUtils.isEmpty(add)) {
                            Toast.makeText(final_bill.this,"Please enter your address", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                        users.child(firebaseUser.getUid()).setValue(detail);

                        startActivity(new Intent(final_bill.this,thank_you.class));

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View v) {
        if(v==cv) {
            add_data();
        }
        else if(v==ch)
        {
            finish();
            startActivity(new Intent(final_bill.this, home_page.class));

        }
    }
}