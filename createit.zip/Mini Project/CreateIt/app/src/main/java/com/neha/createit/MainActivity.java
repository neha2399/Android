package com.dhruvi.createit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private CardView b;
    private EditText ee;
    private EditText ep;
    private TextView t;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;

    //ViewFlipper v_flipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        firebaseAuth=FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser()!=null){
            finish();
            startActivity(new Intent(getApplicationContext(), home_page.class));
        }

        progressDialog=new ProgressDialog(this);
        t=(TextView) findViewById(R.id.textSignUp);

        b=(CardView) findViewById(R.id.login);
        ee=(EditText) findViewById(R.id.textEmail);
        ep=(EditText) findViewById(R.id.textPassword);

        b.setOnClickListener(this);
        t.setOnClickListener(this);
    }

    private void userLogin(){
        String email=ee.getText().toString().trim();
        String password=ep.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Please enter your email",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Please enter your password",Toast.LENGTH_SHORT).show();
            return;
        }
        //if validation is correct

        progressDialog.setMessage("Logging in......");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if(task.isSuccessful()){
                            finish();
                            startActivity(new Intent(MainActivity.this, home_page.class));
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Account does not exist.\nPlease register", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    @Override
    public void onClick(View v) {
        if(v==b){
            userLogin();
        }
        if(v==t){
            Intent s=new Intent(MainActivity.this,register_page.class);
            startActivity(s);
        }
    }
}
